let box = document.querySelector('.form')

let showPopup = ()=>{
    box.classList.toggle('active')
}
